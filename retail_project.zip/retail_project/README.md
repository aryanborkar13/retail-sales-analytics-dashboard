# Retail Sales & Customer Analytics

An end-to-end analytics project: a normalized SQL database, a set of business-question
queries and stored procedures, and an interactive web dashboard — built to showcase
the full analyst workflow, not just isolated queries or a single chart.

## What's inside

```
retail_project/
├── data/                      4 CSVs — ready to load into any SQL database
│   ├── customers.csv          350 customers (region, state, segment, signup date)
│   ├── products.csv           60 products across 4 categories
│   ├── orders.csv             2,600 orders (2023–2025)
│   └── order_items.csv        4,896 line items (qty, discount, net sales, profit, returns)
├── sql/
│   ├── 01_schema.sql          Normalized (3NF) table definitions, PKs/FKs, indexes
│   ├── 02_views.sql           4 reusable views (order detail, monthly sales, CLV, product performance)
│   ├── 03_stored_procedures.sql   4 parameterized procedures (regional revenue, top customers, returns, cohort retention)
│   └── 04_analysis_queries.sql    7 business-question queries (joins, subqueries, window functions)
└── dashboard.html             Self-contained interactive dashboard (open directly in a browser)
```

The data is synthetic but built to behave like a real retail dataset: seasonal spikes
around Nov/Dec, realistic discount and margin patterns, a return-rate signal, and
growth over time — so your SQL and charts show trends worth talking about in an interview.

## How to use it

**Dashboard:** just double-click `dashboard.html` — no server, no install. It has filters
for region, category, segment, and date range, and everything (KPI tiles, 6 charts, 2 tables)
recalculates live in the browser.

**SQL:** run the scripts in order (01 → 04) against MySQL or SQL Server (minor syntax
tweaks noted inline for SQL Server). Each script is commented with what it demonstrates —
normalization, views, stored procedures, subqueries, and window functions (`LAG`, `ROW_NUMBER`,
running totals).

**Regenerate the data:** `python3 generate_data.py` if you want a different random seed
or want to scale the volume up/down.

## Business questions this project answers

- Which region and category drive the most profit — not just revenue?
- Who are the top customers by lifetime value, and which are at risk (no order in 90+ days)?
- Is month-over-month growth accelerating or slowing?
- Do faster shipping modes correlate with higher return rates?
- Which categories have the highest return rate / revenue at risk?

## Using this on your resume

A bullet you could adapt:

> Built an end-to-end retail analytics project on a normalized SQL schema (4 tables, 4 views,
> 4 stored procedures); wrote analytical queries using joins, subqueries, and window functions
> to surface revenue, profit-margin, and customer-retention trends; visualized results in an
> interactive dashboard with live filtering across 4,900+ transactions.

Talking points to be ready for in an interview:
- Why you normalized into 4 tables instead of one flat file (avoids repeating customer/product
  data on every line item, keeps updates consistent)
- Why you used views (reusable, hide join complexity from downstream queries/BI tools)
  vs. stored procedures (parameterized, callable on demand)
- One specific insight you found in the data and what you'd recommend a business do about it
