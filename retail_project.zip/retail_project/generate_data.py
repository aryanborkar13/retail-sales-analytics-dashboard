import numpy as np
import pandas as pd
import random
from datetime import datetime, timedelta

random.seed(42)
np.random.seed(42)

# ---------------------------------------------------------
# 1. CUSTOMERS
# ---------------------------------------------------------
regions = ["North", "South", "East", "West", "Central"]
states_by_region = {
    "North": ["Punjab", "Haryana", "Delhi", "Uttarakhand"],
    "South": ["Karnataka", "Tamil Nadu", "Kerala", "Andhra Pradesh"],
    "East": ["West Bengal", "Odisha", "Bihar", "Jharkhand"],
    "West": ["Maharashtra", "Gujarat", "Rajasthan", "Goa"],
    "Central": ["Madhya Pradesh", "Chhattisgarh", "Uttar Pradesh"],
}
segments = ["Consumer", "Corporate", "Home Office"]

first_names = ["Aarav","Vivaan","Aditya","Vihaan","Arjun","Sai","Reyansh","Ayaan","Krishna","Ishaan",
               "Ananya","Diya","Aadhya","Saanvi","Myra","Aarohi","Anika","Kiara","Riya","Meera",
               "Rohan","Kabir","Dev","Yash","Karan","Neha","Priya","Pooja","Sneha","Isha"]
last_names = ["Sharma","Verma","Patel","Gupta","Iyer","Nair","Reddy","Singh","Mehta","Joshi",
              "Kulkarni","Rao","Das","Chatterjee","Bose","Kapoor","Malhotra","Chauhan","Bhatt","Pillai"]

n_customers = 350
customer_ids = [f"CUST-{i:04d}" for i in range(1, n_customers + 1)]
cust_rows = []
for cid in customer_ids:
    region = random.choice(regions)
    state = random.choice(states_by_region[region])
    name = f"{random.choice(first_names)} {random.choice(last_names)}"
    segment = random.choices(segments, weights=[0.55, 0.30, 0.15])[0]
    signup_date = datetime(2023, 1, 1) + timedelta(days=random.randint(0, 300))
    cust_rows.append([cid, name, segment, region, state, signup_date.strftime("%Y-%m-%d")])

customers = pd.DataFrame(cust_rows, columns=["customer_id", "customer_name", "segment", "region", "state", "signup_date"])

# ---------------------------------------------------------
# 2. PRODUCTS
# ---------------------------------------------------------
categories = {
    "Furniture": ["Chairs", "Tables", "Bookcases", "Storage"],
    "Office Supplies": ["Binders", "Paper", "Art", "Labels", "Fasteners"],
    "Technology": ["Phones", "Accessories", "Machines", "Copiers"],
    "Electronics": ["Audio", "Cameras", "Wearables"],
}
product_adjectives = ["Premium", "Standard", "Deluxe", "Compact", "Pro", "Classic", "Advanced", "Eco"]
product_nouns = {
    "Chairs": "Chair", "Tables": "Table", "Bookcases": "Bookcase", "Storage": "Storage Unit",
    "Binders": "Binder", "Paper": "Paper Pack", "Art": "Art Supply Set", "Labels": "Label Set", "Fasteners": "Fastener Pack",
    "Phones": "Smartphone", "Accessories": "Accessory Kit", "Machines": "Machine", "Copiers": "Copier",
    "Audio": "Speaker", "Cameras": "Camera", "Wearables": "Smartwatch",
}

n_products = 60
prod_rows = []
pid = 1
cat_list = list(categories.items())
for _ in range(n_products):
    cat, subcats = random.choice(cat_list)
    subcat = random.choice(subcats)
    name = f"{random.choice(product_adjectives)} {product_nouns[subcat]}"
    base_cost = {
        "Furniture": random.uniform(1500, 12000),
        "Office Supplies": random.uniform(50, 1500),
        "Technology": random.uniform(2000, 25000),
        "Electronics": random.uniform(800, 15000),
    }[cat]
    margin = random.uniform(1.15, 1.55)
    unit_price = round(base_cost * margin, 2)
    prod_rows.append([f"PROD-{pid:04d}", name, cat, subcat, round(base_cost, 2), unit_price])
    pid += 1

products = pd.DataFrame(prod_rows, columns=["product_id", "product_name", "category", "sub_category", "unit_cost", "unit_price"])

# ---------------------------------------------------------
# 3. ORDERS + ORDER_ITEMS
# ---------------------------------------------------------
ship_modes = ["Standard", "Express", "Same Day"]
start_date = datetime(2023, 1, 1)
end_date = datetime(2025, 12, 31)
date_range_days = (end_date - start_date).days

n_orders = 2600
order_rows = []
item_rows = []
oid_counter = 1
item_counter = 1

# Weight order volume so it grows over time and has seasonal (Nov/Dec) spikes
def sample_order_date():
    day_offset = int(np.clip(np.random.beta(2.2, 1.7) * date_range_days, 0, date_range_days))
    d = start_date + timedelta(days=day_offset)
    if random.random() < 0.18:  # seasonal boost -> push into Nov/Dec of a random year in range
        year = random.choice([2023, 2024, 2025])
        d = datetime(year, random.choice([11, 12]), random.randint(1, 28))
    return d

for _ in range(n_orders):
    order_date = sample_order_date()
    if order_date > end_date:
        order_date = end_date
    cust = random.choice(customer_ids)
    ship_mode = random.choices(ship_modes, weights=[0.6, 0.3, 0.1])[0]
    ship_days = {"Standard": random.randint(4, 7), "Express": random.randint(2, 3), "Same Day": 0}[ship_mode]
    ship_date = order_date + timedelta(days=ship_days)
    order_id = f"ORD-{oid_counter:05d}"

    n_items = random.choices([1, 2, 3, 4], weights=[0.45, 0.30, 0.17, 0.08])[0]
    chosen_products = random.sample(list(products["product_id"]), k=n_items)
    order_has_return = random.random() < 0.06

    for prod_id in chosen_products:
        prod = products.loc[products.product_id == prod_id].iloc[0]
        qty = random.randint(1, 6)
        discount_pct = random.choices([0, 0.05, 0.1, 0.15, 0.2], weights=[0.5, 0.2, 0.15, 0.1, 0.05])[0]
        gross = round(qty * prod.unit_price, 2)
        discount_amt = round(gross * discount_pct, 2)
        net_sales = round(gross - discount_amt, 2)
        profit = round(net_sales - qty * prod.unit_cost, 2)
        returned = "Yes" if (order_has_return and random.random() < 0.5) else "No"

        item_rows.append([
            f"ITEM-{item_counter:06d}", order_id, prod_id, qty, prod.unit_price,
            discount_pct, net_sales, profit, returned
        ])
        item_counter += 1

    order_rows.append([
        order_id, cust, order_date.strftime("%Y-%m-%d"), ship_date.strftime("%Y-%m-%d"),
        ship_mode, "Yes" if order_has_return else "No"
    ])
    oid_counter += 1

orders = pd.DataFrame(order_rows, columns=["order_id", "customer_id", "order_date", "ship_date", "ship_mode", "has_return"])
order_items = pd.DataFrame(item_rows, columns=[
    "order_item_id", "order_id", "product_id", "quantity", "unit_price",
    "discount_pct", "net_sales", "profit", "returned"
])

# ---------------------------------------------------------
# Save
# ---------------------------------------------------------
customers.to_csv("data/customers.csv", index=False)
products.to_csv("data/products.csv", index=False)
orders.to_csv("data/orders.csv", index=False)
order_items.to_csv("data/order_items.csv", index=False)

print("customers:", customers.shape)
print("products:", products.shape)
print("orders:", orders.shape)
print("order_items:", order_items.shape)
print("date range:", orders.order_date.min(), "to", orders.order_date.max())
print("total net sales:", round(order_items.net_sales.sum(), 2))
print("total profit:", round(order_items.profit.sum(), 2))
