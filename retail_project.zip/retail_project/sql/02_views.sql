-- ============================================================
-- Views — reusable building blocks for reporting & the dashboard
-- ============================================================
USE retail_analytics;

-- ------------------------------------------------------------
-- v_order_line_detail
-- Flattens order + customer + product + line item into one
-- analysis-ready row. This is the view most reports are built on.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW v_order_line_detail AS
SELECT
    oi.order_item_id,
    o.order_id,
    o.order_date,
    o.ship_date,
    DATEDIFF(o.ship_date, o.order_date)   AS days_to_ship,
    o.ship_mode,
    c.customer_id,
    c.customer_name,
    c.segment,
    c.region,
    c.state,
    p.product_id,
    p.product_name,
    p.category,
    p.sub_category,
    oi.quantity,
    oi.unit_price,
    oi.discount_pct,
    oi.net_sales,
    oi.profit,
    oi.returned
FROM order_items oi
JOIN orders o     ON oi.order_id = o.order_id
JOIN customers c  ON o.customer_id = c.customer_id
JOIN products p   ON oi.product_id = p.product_id;

-- ------------------------------------------------------------
-- v_monthly_sales
-- Pre-aggregated monthly KPIs — feeds trend charts directly.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW v_monthly_sales AS
SELECT
    DATE_FORMAT(order_date, '%Y-%m')  AS year_month,
    region,
    category,
    SUM(net_sales)                    AS total_sales,
    SUM(profit)                       AS total_profit,
    COUNT(DISTINCT order_id)          AS order_count,
    SUM(quantity)                     AS units_sold
FROM v_order_line_detail
GROUP BY DATE_FORMAT(order_date, '%Y-%m'), region, category;

-- ------------------------------------------------------------
-- v_customer_lifetime_value
-- One row per customer: total spend, order count, recency.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW v_customer_lifetime_value AS
SELECT
    c.customer_id,
    c.customer_name,
    c.segment,
    c.region,
    COUNT(DISTINCT o.order_id)        AS total_orders,
    SUM(oi.net_sales)                 AS lifetime_value,
    SUM(oi.profit)                    AS lifetime_profit,
    MIN(o.order_date)                 AS first_order_date,
    MAX(o.order_date)                 AS last_order_date,
    DATEDIFF(CURDATE(), MAX(o.order_date)) AS days_since_last_order
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name, c.segment, c.region;

-- ------------------------------------------------------------
-- v_product_performance
-- One row per product: revenue, profit margin, return rate.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW v_product_performance AS
SELECT
    p.product_id,
    p.product_name,
    p.category,
    p.sub_category,
    SUM(oi.quantity)                                  AS units_sold,
    SUM(oi.net_sales)                                 AS total_sales,
    SUM(oi.profit)                                    AS total_profit,
    ROUND(SUM(oi.profit) / NULLIF(SUM(oi.net_sales),0) * 100, 2) AS profit_margin_pct,
    ROUND(SUM(CASE WHEN oi.returned = 'Yes' THEN 1 ELSE 0 END)
          / COUNT(*) * 100, 2)                        AS return_rate_pct
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.category, p.sub_category;
