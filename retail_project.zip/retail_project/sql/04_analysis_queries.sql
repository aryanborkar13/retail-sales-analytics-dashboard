-- ============================================================
-- Analysis Queries — the "insight layer" of the project.
-- Each query answers a real business question and demonstrates
-- a specific SQL concept (joins, subqueries, aggregates, window fns).
-- ============================================================
USE retail_analytics;

-- ------------------------------------------------------------
-- Q1. Which region generates the most profit, and what's its
--     profit margin vs. the company average? (subquery in SELECT)
-- ------------------------------------------------------------
SELECT
    c.region,
    SUM(oi.net_sales)  AS total_sales,
    SUM(oi.profit)     AS total_profit,
    ROUND(SUM(oi.profit) / SUM(oi.net_sales) * 100, 2) AS region_margin_pct,
    (SELECT ROUND(SUM(profit) / SUM(net_sales) * 100, 2) FROM v_order_line_detail) AS company_margin_pct
FROM customers c
JOIN orders o       ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.region
ORDER BY total_profit DESC;

-- ------------------------------------------------------------
-- Q2. Customers whose lifetime value is above the overall
--     average (subquery in WHERE) — a simple "high value" segment.
-- ------------------------------------------------------------
SELECT customer_id, customer_name, region, lifetime_value
FROM v_customer_lifetime_value
WHERE lifetime_value > (
    SELECT AVG(lifetime_value) FROM v_customer_lifetime_value
)
ORDER BY lifetime_value DESC;

-- ------------------------------------------------------------
-- Q3. Month-over-month revenue growth (window function: LAG)
-- ------------------------------------------------------------
SELECT
    year_month,
    total_sales,
    LAG(total_sales) OVER (ORDER BY year_month)                          AS prev_month_sales,
    ROUND(
        (total_sales - LAG(total_sales) OVER (ORDER BY year_month))
        / LAG(total_sales) OVER (ORDER BY year_month) * 100, 2
    )                                                                    AS mom_growth_pct
FROM (
    SELECT DATE_FORMAT(order_date, '%Y-%m') AS year_month, SUM(net_sales) AS total_sales
    FROM v_order_line_detail
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
) monthly
ORDER BY year_month;

-- ------------------------------------------------------------
-- Q4. Top 3 best-selling products per category (window function:
--     ROW_NUMBER partitioned by category)
-- ------------------------------------------------------------
SELECT category, product_name, total_sales, rnk
FROM (
    SELECT
        category,
        product_name,
        total_sales,
        ROW_NUMBER() OVER (PARTITION BY category ORDER BY total_sales DESC) AS rnk
    FROM v_product_performance
) ranked
WHERE rnk <= 3
ORDER BY category, rnk;

-- ------------------------------------------------------------
-- Q5. Customers who have NOT ordered in the last 90 days
--     ("at risk" list — NOT IN / correlated subquery pattern)
-- ------------------------------------------------------------
SELECT c.customer_id, c.customer_name, c.region, MAX(o.order_date) AS last_order_date
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_name, c.region
HAVING MAX(o.order_date) < DATE_SUB(
    (SELECT MAX(order_date) FROM orders), INTERVAL 90 DAY
)
ORDER BY last_order_date;

-- ------------------------------------------------------------
-- Q6. Ship-mode performance: average days to ship vs. return rate
--     (does faster shipping correlate with more returns?)
-- ------------------------------------------------------------
SELECT
    ship_mode,
    ROUND(AVG(days_to_ship), 2)                                              AS avg_days_to_ship,
    COUNT(DISTINCT order_id)                                                 AS orders,
    ROUND(SUM(CASE WHEN returned = 'Yes' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS return_rate_pct
FROM v_order_line_detail
GROUP BY ship_mode
ORDER BY avg_days_to_ship;

-- ------------------------------------------------------------
-- Q7. Running total of profit over time (window function: SUM OVER)
-- ------------------------------------------------------------
SELECT
    year_month,
    total_profit,
    SUM(total_profit) OVER (ORDER BY year_month) AS cumulative_profit
FROM (
    SELECT DATE_FORMAT(order_date, '%Y-%m') AS year_month, SUM(profit) AS total_profit
    FROM v_order_line_detail
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
) monthly
ORDER BY year_month;
