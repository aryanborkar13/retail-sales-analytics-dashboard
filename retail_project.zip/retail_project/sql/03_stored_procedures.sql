-- ============================================================
-- Stored Procedures — parameterized reports a BI tool or app
-- could call directly instead of hardcoding queries.
-- ============================================================
USE retail_analytics;

DELIMITER $$

-- ------------------------------------------------------------
-- sp_monthly_revenue_by_region
-- Revenue + profit for a given region between two dates.
-- Pass region = 'ALL' to get every region.
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_monthly_revenue_by_region $$
CREATE PROCEDURE sp_monthly_revenue_by_region (
    IN p_region     VARCHAR(20),
    IN p_start_date DATE,
    IN p_end_date   DATE
)
BEGIN
    SELECT
        DATE_FORMAT(o.order_date, '%Y-%m') AS year_month,
        c.region,
        SUM(oi.net_sales)                  AS total_sales,
        SUM(oi.profit)                     AS total_profit,
        COUNT(DISTINCT o.order_id)         AS order_count
    FROM orders o
    JOIN customers c    ON o.customer_id = c.customer_id
    JOIN order_items oi ON o.order_id = oi.order_id
    WHERE (p_region = 'ALL' OR c.region = p_region)
      AND o.order_date BETWEEN p_start_date AND p_end_date
    GROUP BY DATE_FORMAT(o.order_date, '%Y-%m'), c.region
    ORDER BY year_month;
END $$

-- ------------------------------------------------------------
-- sp_top_customers
-- Top N customers by lifetime spend.
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_top_customers $$
CREATE PROCEDURE sp_top_customers (
    IN p_limit INT
)
BEGIN
    SELECT
        c.customer_id,
        c.customer_name,
        c.segment,
        c.region,
        SUM(oi.net_sales) AS lifetime_value,
        COUNT(DISTINCT o.order_id) AS total_orders
    FROM customers c
    JOIN orders o       ON c.customer_id = o.customer_id
    JOIN order_items oi ON o.order_id = oi.order_id
    GROUP BY c.customer_id, c.customer_name, c.segment, c.region
    ORDER BY lifetime_value DESC
    LIMIT p_limit;
END $$

-- ------------------------------------------------------------
-- sp_product_return_summary
-- Return rate + lost revenue per category, for QA/supplier review.
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_product_return_summary $$
CREATE PROCEDURE sp_product_return_summary ()
BEGIN
    SELECT
        p.category,
        COUNT(*)                                                        AS total_line_items,
        SUM(CASE WHEN oi.returned = 'Yes' THEN 1 ELSE 0 END)            AS returned_items,
        ROUND(SUM(CASE WHEN oi.returned = 'Yes' THEN 1 ELSE 0 END)
              / COUNT(*) * 100, 2)                                      AS return_rate_pct,
        ROUND(SUM(CASE WHEN oi.returned = 'Yes' THEN oi.net_sales ELSE 0 END), 2) AS revenue_at_risk
    FROM order_items oi
    JOIN products p ON oi.product_id = p.product_id
    GROUP BY p.category
    ORDER BY return_rate_pct DESC;
END $$

-- ------------------------------------------------------------
-- sp_customer_cohort_retention
-- Signup-month cohorts vs. how many customers ordered again in
-- each subsequent month (simple repeat-purchase view).
-- ------------------------------------------------------------
DROP PROCEDURE IF EXISTS sp_customer_cohort_retention $$
CREATE PROCEDURE sp_customer_cohort_retention ()
BEGIN
    SELECT
        DATE_FORMAT(c.signup_date, '%Y-%m')  AS cohort_month,
        COUNT(DISTINCT c.customer_id)        AS cohort_size,
        COUNT(DISTINCT CASE
            WHEN o.order_date > c.signup_date THEN o.customer_id END) AS repeat_customers,
        ROUND(COUNT(DISTINCT CASE
            WHEN o.order_date > c.signup_date THEN o.customer_id END)
            / COUNT(DISTINCT c.customer_id) * 100, 2)                 AS repeat_rate_pct
    FROM customers c
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY DATE_FORMAT(c.signup_date, '%Y-%m')
    ORDER BY cohort_month;
END $$

DELIMITER ;

-- ------------------------------------------------------------
-- Example calls
-- ------------------------------------------------------------
-- CALL sp_monthly_revenue_by_region('West', '2023-01-01', '2025-12-31');
-- CALL sp_top_customers(10);
-- CALL sp_product_return_summary();
-- CALL sp_customer_cohort_retention();
