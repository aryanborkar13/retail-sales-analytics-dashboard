-- ============================================================
-- Retail Sales & Customer Analytics — Schema
-- Normalized to 3NF: customers, products, orders, order_items
-- Tested against MySQL 8 / SQL Server syntax (minor tweaks noted)
-- ============================================================

CREATE DATABASE IF NOT EXISTS retail_analytics;
USE retail_analytics;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

-- ------------------------------------------------------------
-- CUSTOMERS
-- ------------------------------------------------------------
CREATE TABLE customers (
    customer_id     VARCHAR(10)  PRIMARY KEY,
    customer_name   VARCHAR(100) NOT NULL,
    segment         VARCHAR(20)  NOT NULL,      -- Consumer / Corporate / Home Office
    region          VARCHAR(20)  NOT NULL,
    state           VARCHAR(50)  NOT NULL,
    signup_date     DATE         NOT NULL
);

-- ------------------------------------------------------------
-- PRODUCTS
-- ------------------------------------------------------------
CREATE TABLE products (
    product_id      VARCHAR(10)  PRIMARY KEY,
    product_name    VARCHAR(100) NOT NULL,
    category        VARCHAR(30)  NOT NULL,
    sub_category    VARCHAR(30)  NOT NULL,
    unit_cost       DECIMAL(10,2) NOT NULL,
    unit_price      DECIMAL(10,2) NOT NULL
);

-- ------------------------------------------------------------
-- ORDERS  (order header — one row per order)
-- ------------------------------------------------------------
CREATE TABLE orders (
    order_id        VARCHAR(10)  PRIMARY KEY,
    customer_id     VARCHAR(10)  NOT NULL,
    order_date      DATE         NOT NULL,
    ship_date       DATE         NOT NULL,
    ship_mode       VARCHAR(20)  NOT NULL,      -- Standard / Express / Same Day
    has_return      VARCHAR(3)   NOT NULL DEFAULT 'No',
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- ------------------------------------------------------------
-- ORDER_ITEMS  (line items — normalizes the many-to-many
-- relationship between orders and products, avoids repeating
-- groups so the table is in 3NF)
-- ------------------------------------------------------------
CREATE TABLE order_items (
    order_item_id   VARCHAR(12)  PRIMARY KEY,
    order_id        VARCHAR(10)  NOT NULL,
    product_id      VARCHAR(10)  NOT NULL,
    quantity        INT          NOT NULL,
    unit_price      DECIMAL(10,2) NOT NULL,
    discount_pct    DECIMAL(4,2)  NOT NULL DEFAULT 0,
    net_sales       DECIMAL(12,2) NOT NULL,     -- qty * price * (1 - discount)
    profit          DECIMAL(12,2) NOT NULL,     -- net_sales - qty * unit_cost
    returned        VARCHAR(3)   NOT NULL DEFAULT 'No',
    CONSTRAINT fk_items_order
        FOREIGN KEY (order_id) REFERENCES orders(order_id),
    CONSTRAINT fk_items_product
        FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- ------------------------------------------------------------
-- Indexes to speed up the analytical queries in 04_analysis_queries.sql
-- ------------------------------------------------------------
CREATE INDEX idx_orders_customer   ON orders(customer_id);
CREATE INDEX idx_orders_date       ON orders(order_date);
CREATE INDEX idx_items_order       ON order_items(order_id);
CREATE INDEX idx_items_product     ON order_items(product_id);

-- ------------------------------------------------------------
-- Load data (MySQL syntax — adjust path / use BULK INSERT for SQL Server)
-- ------------------------------------------------------------
-- LOAD DATA LOCAL INFILE 'data/customers.csv'
--   INTO TABLE customers FIELDS TERMINATED BY ',' ENCLOSED BY '"'
--   LINES TERMINATED BY '\n' IGNORE 1 ROWS;
--
-- LOAD DATA LOCAL INFILE 'data/products.csv'
--   INTO TABLE products FIELDS TERMINATED BY ',' ENCLOSED BY '"'
--   LINES TERMINATED BY '\n' IGNORE 1 ROWS;
--
-- LOAD DATA LOCAL INFILE 'data/orders.csv'
--   INTO TABLE orders FIELDS TERMINATED BY ',' ENCLOSED BY '"'
--   LINES TERMINATED BY '\n' IGNORE 1 ROWS;
--
-- LOAD DATA LOCAL INFILE 'data/order_items.csv'
--   INTO TABLE order_items FIELDS TERMINATED BY ',' ENCLOSED BY '"'
--   LINES TERMINATED BY '\n' IGNORE 1 ROWS;
